/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package middleware;

import database.DataBase;
import java.io.Serializable;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

/**
 *
 * @author pedro
 */
public class ServiceImpl extends UnicastRemoteObject implements Service, Serializable{
    private DataBase db;
    
    public ServiceImpl(String host, String dbase, String user, String pass) throws RemoteException{
        db = new DataBase(host, dbase, user, pass);
    }
    
    
}
