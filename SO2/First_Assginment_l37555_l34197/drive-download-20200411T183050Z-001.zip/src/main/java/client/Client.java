/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import java.util.Scanner;
import middleware.Service;

/**
 *
 * @author pedro
 */
public class Client {
    
    
    public String regHost;
    public String regPort;
    public Scanner sc;
  
    public Client(String regHost, String regPort){
        this.regHost = regHost;
        this.regPort = regPort;
        this.sc  = new Scanner(System.in);
    }
    
    public void run(){
        try {
            Service rmiObject = (Service) java.rmi.Naming.lookup("rmi://" + regHost + ":" +
                                                                           regPort + "/service");
            menu(rmiObject);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void menu(Service service) throws Exception
    {
        
    }
    
    
    public static void main(String args[]) throws Exception {
	String regHost;
	String regPort;

	if (args.length != 2) { // requer 2 argumentos
	    System.out.println
		("Missing argument");
	    System.exit(1);
	}
	regHost= args[0];
	regPort= args[1];
        
        Client client =  new Client(args[0], args[1]);
        client.run();
        
    }
}
