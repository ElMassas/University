/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

/**
 *
 * @author pedro
 */
public class DataBase implements java.rmi.Remote{
    
    public Connection con;
    public Statement stmt;
    
    public DataBase(String PG_HOST, String PG_DB, String USER, String PASSWORD){
        
        this.con = null;
        this.stmt = null;
        
        try{
            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection("jdbc:postgresql://"+PG_HOST+":5432/"+PG_DB, USER, PASSWORD);
            this.stmt = this.con.createStatement();
        }
        catch (Exception e){
            e.printStackTrace();
            System.err.println("Problemas a iniciar a connection");
        }
    }
    
}
