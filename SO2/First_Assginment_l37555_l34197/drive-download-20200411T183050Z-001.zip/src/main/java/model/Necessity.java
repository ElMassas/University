/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;

/**
 *
 * @author pedro
 */
public class Necessity implements Serializable{
    
    private long id_user;
    private long id_product;
    private int quantity;

    public Necessity() {
    }

    public Necessity(long id_user, long id_product, int quantity) {
        this.id_user = id_user;
        this.id_product = id_product;
        this.quantity = quantity;
    }

    public long getId_user() {
        return id_user;
    }

    public void setId_user(long id_user) {
        this.id_user = id_user;
    }

    public long getId_product() {
        return id_product;
    }

    public void setId_product(long id_product) {
        this.id_product = id_product;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
    
    
}
