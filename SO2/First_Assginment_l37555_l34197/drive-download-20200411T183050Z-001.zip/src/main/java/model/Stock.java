/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;

/**
 *
 * @author pedro
 */
public class Stock implements Serializable{
    
    private long id_product;
    private long id_store;
    private int quantity;

    public Stock() {
    }

    public Stock(long id_product, long id_store, int quantity) {
        this.id_product = id_product;
        this.id_store = id_store;
        this.quantity = quantity;
    }

    public long getId_product() {
        return id_product;
    }

    public void setId_product(long id_product) {
        this.id_product = id_product;
    }

    public long getId_store() {
        return id_store;
    }

    public void setId_store(long id_store) {
        this.id_store = id_store;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
    
    
}
